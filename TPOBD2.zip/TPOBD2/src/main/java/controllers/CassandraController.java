package controllers;

import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.api.core.cql.ResultSet;

public class CassandraController {

    private CqlSession session;

    public CassandraController(CqlSession session) {
        this.session = session;
    }

    public void close() {
        session.close();
    }

    public void createTable(String query) {
        session.execute(query);
    }

    public ResultSet executeQuery(String query) {

        return session.execute(query);
    }
}

/*
DATABASE ADMINISTRATOR
{
  "clientID": "geRBzRuGuJhNFAekneEUBBkT"
  "clientSecret": "ZIWaDq_Jrd1Qh77EU7hXD+cu6nbG7gdL7lAXdDTf+qGFv-+ncy2I8-YtfADgBb1AZa2-0d4Lrz849.96oDNELYZnEEfzC-Ch_1GxgA1Gvp3W+U9K.oprT,1y8skcCZyi"
  "token": "AstraCS:geRBzRuGuJhNFAekneEUBBkT:4a797e9bec5c7df24b5c2974b92b425e799b787068980cb01542ec4b6ffdccb5"
}

*/

