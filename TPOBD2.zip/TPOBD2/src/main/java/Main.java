
import model.*;
import database.*;
import org.bson.types.ObjectId;

import com.datastax.oss.driver.api.core.CqlSession;

import redis.clients.jedis.Jedis;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class Main {
    public static void main(String[] args) {


        // Crear conexión a MongoDB y Redis
        RedisConnection.connect();
        MongoDBConnection.connect();
        Catalogo catalogo = new Catalogo();
        catalogo.agregarProducto("limon",10.50,10,"https://th.bing.com/th/id/R.ece21561bf1be5aecf7a637633355f09?rik=uNxWx%2fZ1YI3%2b1w&pid=ImgRaw&r=0","Excelente producto","www.youtube.com");
        catalogo.agregarProducto("manzana",20.50,2,"https://th.bing.com/th/id/R.ece21561bf1be5aecf7a637633355f09?rik=uNxWx%2fZ1YI3%2b1w&pid=ImgRaw&r=0","Excelente producto","www.youtube.com");
        catalogo.agregarProducto("pera",3.50,5,"https://th.bing.com/th/id/R.ece21561bf1be5aecf7a637633355f09?rik=uNxWx%2fZ1YI3%2b1w&pid=ImgRaw&r=0","Excelente producto","www.youtube.com");
        catalogo.agregarProducto("uva",30.00,1,"https://th.bing.com/th/id/R.ece21561bf1be5aecf7a637633355f09?rik=uNxWx%2fZ1YI3%2b1w&pid=ImgRaw&r=0","Excelente producto","www.youtube.com");
        catalogo.agregarProducto("sandia",100.50,2,"https://th.bing.com/th/id/R.ece21561bf1be5aecf7a637633355f09?rik=uNxWx%2fZ1YI3%2b1w&pid=ImgRaw&r=0","Excelente producto","www.youtube.com");

        Usuario usuario = new Usuario("iep","1234","Ivan Pace","30303030","nose al 1120");

        Usuario usuario2 = new Usuario("gonza","1234","Gonzalo Gioria","1111111","av rivadavia 1562");

        Usuario usuario3 = new Usuario("juli","1234","Julian Rodriguez","123456787","chacabuco 24");

        SesionUsuario session1 = new SesionUsuario(usuario);

        CarritoDeCompras carrito = new CarritoDeCompras(usuario);

        carrito.ingresarProducto(catalogo.obtenerProducto("manzana"), 1);

        carrito.ingresarProducto(catalogo.obtenerProducto("pera"), 1);
        carrito.ingresarProducto(catalogo.obtenerProducto("uva"), 1);
        carrito.ingresarProducto(catalogo.obtenerProducto("sandia"), 1);
        carrito.eliminarProducto(catalogo.obtenerProducto("sandia"));
        carrito.eliminarProducto(catalogo.obtenerProducto("pera"));
        carrito.ingresarProducto(catalogo.obtenerProducto("sandia"), 1);
        carrito.ingresarProducto(catalogo.obtenerProducto("pera"), 100);
        carrito.ingresarProducto(catalogo.obtenerProducto("pera"), 1);

        Pedido pedido = carrito.confirmarCarrito();
        pedido.listarProductosPedido();
        Factura factura  = pedido.confirmarPedido();

        //Cerrar sesión
        session1.cerrarSesion();

        // Cerrar conexión a MongoDB y Redis
        MongoDBConnection.closeConnection();
        RedisConnection.closeConnection();

        */
        RedisConnection.connect();
        CassandraConnection.connect();
        MongoDBConnection.connect();

        



}


}
