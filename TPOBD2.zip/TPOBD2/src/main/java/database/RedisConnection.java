package database;

import redis.clients.jedis.Connection;
import redis.clients.jedis.Jedis;

//Vamos a usar Redis para guardar los datos de los usuarios.
//Redis es una base de datos en memoria, por lo que es muy rápida.
//En este caso, vamos a usarla como una base de datos clave-valor.
//Cada usuario tendrá una clave, que será su nombre de usuario, y un valor, que será su contraseña.
public class RedisConnection {

    private static Jedis jedis;

    public class TestRedis {
        public static void main(String[] args) {

        }
    }
    public static void connect() {
        jedis = new Jedis("redis://default:123456@redis-15473.c276.us-east-1-2.ec2.cloud.redislabs.com:15473");
        System.out.println("Connection to server successfully");
        //check whether server is running or not
        System.out.println("Server is running: "+jedis.ping() + " Conectado a Redis");
    }

    public static Jedis getConnection() {
        if (jedis == null) {
            connect();
        }
        return jedis;
    }

    public static void closeConnection() {
        if (jedis != null) {
            jedis.close();
            jedis = null;
        }
    }
}
