package database;
import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.api.core.cql.ResultSet;
import com.datastax.oss.driver.api.core.cql.Row;
import java.nio.file.Path;
import java.nio.file.Paths;

public class CassandraConnection {
    public static CqlSession connect() {
    CqlSession  session = CqlSession.builder()
         .withCloudSecureConnectBundle(Paths.get("C:\\repos\\TPOBD2\\src\\secure-connect-log.zip"))
        .withAuthCredentials("geRBzRuGuJhNFAekneEUBBkT","ZIWaDq_Jrd1Qh77EU7hXD+cu6nbG7gdL7lAXdDTf+qGFv-+ncy2I8-YtfADgBb1AZa2-0d4Lrz849.96oDNELYZnEEfzC-Ch_1GxgA1Gvp3W+U9K.oprT,1y8skcCZyi")
        .build();
        return session;

        /*
        try (CqlSession session = CqlSession.builder()
                .withCloudSecureConnectBundle(Paths.get("C:\\repos\\TPOBD2\\src\\secure-connect-log.zip"))
                //.withCloudSecureConnectBundle(Paths.get("<</PATH/TO/>>secure-connect-log.zip"))
                .withAuthCredentials("geRBzRuGuJhNFAekneEUBBkT","ZIWaDq_Jrd1Qh77EU7hXD+cu6nbG7gdL7lAXdDTf+qGFv-+ncy2I8-YtfADgBb1AZa2-0d4Lrz849.96oDNELYZnEEfzC-Ch_1GxgA1Gvp3W+U9K.oprT,1y8skcCZyi")
                .build()) {
            // Select the release_version from the system.local table:
            ResultSet rs = session.execute("select release_version from system.local");
            Row row = rs.one();
            //Print the results of the CQL query to the console:
            if (row != null) {
                System.out.println(row.getString("release_version"));
                System.out.println("Conectado a Cassandra");
            } else {
                System.out.println("An error occurred.");
            }
        }
        System.exit(0);
        */
    }
    public static void closeSession(CqlSession session){
        if(session != null){
            session.execute("", "");
            session.close();
        }
    }

    public void execute(CqlSession session,String query) {
        session.execute(query);
    }
}

/*
DATABASE ADMINISTRATOR
{
  "clientID": "geRBzRuGuJhNFAekneEUBBkT"
  "clientSecret": "ZIWaDq_Jrd1Qh77EU7hXD+cu6nbG7gdL7lAXdDTf+qGFv-+ncy2I8-YtfADgBb1AZa2-0d4Lrz849.96oDNELYZnEEfzC-Ch_1GxgA1Gvp3W+U9K.oprT,1y8skcCZyi"
  "token": "AstraCS:geRBzRuGuJhNFAekneEUBBkT:4a797e9bec5c7df24b5c2974b92b425e799b787068980cb01542ec4b6ffdccb5"
}

*/
