package model;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import database.MongoDBConnection;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.Date;

public class Pago {
    private ObjectId idpago;
    private ObjectId idfactura;
    private String mediodepago;
    private Double monto;
    private Usuario usuario;
    private Date fecha;


    // constructor
    public Pago(Usuario usuario, Double monto, String mediodepago, ObjectId idfactura) {
        this.mediodepago = mediodepago;
        this.idfactura = idfactura;
        this.monto = monto;
        this.usuario = usuario;
        this.fecha = new Date();
        generarPago();
    }

    public void generarPago() {
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> pagos = database.getCollection("pagos");
        Document doc = new Document("mediodepago", this.mediodepago)
                .append("idfactura", this.idfactura)
                .append("monto", this.monto)
                .append("usuario", this.usuario)
                .append("fecha", this.fecha);
        pagos.insertOne(doc);
        this.idpago = (ObjectId) doc.get("_id");
    }

    public void eliminarPago(Factura factura) {
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> pagos = database.getCollection("pagos");
        pagos.deleteOne(Filters.and(Filters.eq("idfactura", idfactura)));
        factura.setEstadopagofactura(false);
    }

    public ObjectId getIdpago() {
        return idpago;
    }

    public ObjectId getIdfactura() {
        return idfactura;
    }

    public String getMediodepago() {
        return mediodepago;
    }

    public Double getMonto() {
        return monto;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public Date getFecha() {
        return fecha;
    }
}
