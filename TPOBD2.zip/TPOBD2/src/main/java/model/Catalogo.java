package model;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import database.MongoDBConnection;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.ArrayList;

public class Catalogo {
    private ObjectId id;

    ArrayList<Producto> catalogo = new ArrayList();

    public Catalogo() {
        this.id = new ObjectId();
    }

    public void agregarProducto(String nombre, Double precio, int stock, String foto, String comentarios, String videos){
        Producto producto = new Producto(nombre, precio,stock,foto,comentarios,videos);
        catalogo.add(producto);
    }

    public void cambiarNombreProducto(String nombre, String nuevonombre){
        for (Producto producto : catalogo) {
            if (producto.getNombre() == nombre) {
                producto.setnombre(nuevonombre);
                break;
            }
        }
    }

    public void cambiarPrecioProducto(String nombre, Double precio){
        for (Producto producto : catalogo) {
            if (producto.getNombre() == nombre) {
                producto.setPrecio(precio);
                break;
            }
        }
    }

    public void cambiarStockProducto(String nombre, int stock){
        for (Producto producto : catalogo) {
            if (producto.getNombre() == nombre) {
                producto.setstock(stock);
                break;
            }
        }
    }

    public void quitarProducto(String nombre){
        for (Producto producto : catalogo) {
            if (producto.getNombre() == nombre) {
                producto.eliminarProducto();
                catalogo.remove(producto);
                break;
            }
        }
    }

    public Producto obtenerProducto(String nombre){
        for (Producto producto : catalogo) {
            if (producto.getNombre() == nombre) {
                return(producto);
            }
        }
        return null;
    }

    public void listarCatalogo(){
        for (Producto producto : catalogo) {
            System.out.printf("Nombre: "+producto.getNombre()+" - Precio: "+producto.getPrecio());
        }
    }

}
