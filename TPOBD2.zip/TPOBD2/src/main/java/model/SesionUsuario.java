package model;

import database.RedisConnection;
import org.bson.types.ObjectId;
import redis.clients.jedis.Jedis;

import java.time.DateTimeException;
import java.util.Date;
import java.util.UUID;

public class SesionUsuario {
    private static Jedis jedis;
    private Usuario usuario;
    private UUID id;
    private Date iniciosession;

    private Date finsession;

    private String token;

    private boolean estadosession;

    // constructor
    public SesionUsuario(Usuario usuario) {
        this.usuario = usuario;
        this.iniciosession = new Date();
        this.estadosession = true;
        crearSession(usuario);
    }

    //--falta agregar datos
    public void crearSession(Usuario usuario) {
        Jedis jedis = RedisConnection.getConnection();
        jedis.mset(String.valueOf(this.id),this.token, this.usuario.getUsername());
    }

    //--FALTA UNA FUNCION QUE RECUPERE LA SESSION COMPLETA

    public void cerrarSesion() {
        Jedis jedis = RedisConnection.getConnection();
        jedis.del(this.token);
        this.finsession = new Date();
        this.estadosession = false;
    }

    public static long obtenerDuracionSesion(Usuario usuario) {
        if (jedis == null) {
            jedis = RedisConnection.getConnection();
        }
        String tiempoInicio = jedis.get(usuario.getUsername());
        if (tiempoInicio == null) {
            return 0;
        } else {
            // Calcular la duración de la sesión en minutos
            return (System.currentTimeMillis() - Long.parseLong(tiempoInicio));
        }
    }

    public static String obtenerCategoriaUsuario(Usuario usuario) {
        long duracionSesion = obtenerDuracionSesion(usuario);
        if (duracionSesion > 240) {
            return "TOP";
        } else if (duracionSesion > 120) {
            return "MEDIUM";
        } else {
            return "LOW";
        }
    }
}
