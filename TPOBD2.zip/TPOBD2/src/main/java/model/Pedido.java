package model;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import database.MongoDBConnection;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Pedido {
    private ObjectId idpedido;
    private int cantidad;
    private Date fecha;
    private Usuario usuario;

    private ObjectId idCarrito;

    ArrayList<Producto> productos = new ArrayList();

    ArrayList<Double> descuentos = new ArrayList();

    ArrayList<Double> impuestos = new ArrayList();

    private Double impuestostotales;
    private Double descuentototal;

    private boolean estadopedido;

    private Double total;

    public Pedido(Usuario usuario, ObjectId idCarrito) {
        this.usuario = usuario;
        this.fecha = new Date();
        this.idCarrito = idCarrito;
        this.estadopedido = true;
        crearPedido();
    }

    public void ingresarDTO(Double valor){
        descuentos.add(valor);
    }

    public void ingresarImpuesto(Double valor){
        impuestos.add(valor);
    }

    public void calcularimpuestos(){
        this.impuestostotales = 0.00;
        for (Producto producto : productos) {
            for (Double impuesto: impuestos){
                this.impuestostotales = this.impuestostotales + (producto.getPrecio() * impuesto);
            }
        }
    }
    public void calcularDTO(){
        this.descuentototal = 0.00;
        for (Producto producto : productos) {
            for (Double descuento: descuentos){
                this.descuentototal = this.descuentototal + (producto.getPrecio() * descuento);
            }
        }
    }
    public void calcularTotal(){
        calcularDTO();
        calcularimpuestos();
        this.total = 0.00;
        for (Producto producto : productos) {
            this.total = this.total + (producto.getPrecio());
        }
        this.total = (this.total + this.impuestostotales) - this.descuentototal;
    }

    public String consultarDuenoCarrito(){
        return this.usuario.getNombre();
    }

    public void crearPedido() {
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> pedidos = database.getCollection("pedidos");
        Document doc = new Document("usuario", this.usuario)
                .append("fecha", this.fecha)
                .append("idCarrito", this.idCarrito)
                .append("impuestos", this.impuestostotales)
                .append("descuentos", this.descuentototal)
                .append("estadopedido", this.estadopedido)
                .append("descuentos", this.total)
                .append("impuestos", this.impuestos);
        pedidos.insertOne(doc);
        this.idpedido = (ObjectId) doc.get("_id");
    }
    public void agregarProducto(Producto productonuevo, int cantidad) {
                MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
                MongoCollection<Document> pedidosdetalle = database.getCollection("pedidosdetalle");
                Document doc = new Document("idpedido", this.idpedido)
                        .append("fecha",new Date())
                        .append("cantidad", cantidad)
                        .append("idproducto", productonuevo.getId())
                        .append("precio", productonuevo.getPrecio() * cantidad)
                        .append("producto", productonuevo);
                pedidosdetalle.insertOne(doc);
                productos.add(productonuevo);
    }
    public void eliminarProducto(ObjectId idpedido, Producto producto) {
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> pedidosdetalle = database.getCollection("pedidosdetalle");
        pedidosdetalle.deleteOne(Filters.and(Filters.eq("idproducto", producto.getId()),Filters.eq("idpedido",idpedido)));
        productos.remove(producto);
    }
    public Producto obtenerProductoPorNombre(String nombre){
        Producto productotoReturn = null;
        for (Producto producto : productos) {
            if (producto.getNombre() == nombre) {
                productotoReturn = producto;
                break;
            }
        }
        return(productotoReturn);
    }
    public void listarProductosPedido(){
        for (Producto producto : productos) {
            System.out.printf("Nombre: "+producto.getNombre()+" - Precio: "+producto.getPrecio());
        }
    }

    public Factura confirmarPedido(){
        Factura factura = new Factura(usuario, this.idpedido, descuentos, impuestos, descuentototal, impuestostotales, total);
            for (Producto producto : productos) {
                factura.agregarProducto(producto,1);
        }
        return factura;
        //FALTA MIRAR ABAJO
    }

    public ObjectId getIdpedido() {
        return idpedido;
    }

    public int getCantidad() {
        return cantidad;
    }

    public Date getFecha() {
        return fecha;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public ObjectId getIdCarrito() {
        return idCarrito;
    }

    public Double getImpuestostotales() {
        return impuestostotales;
    }

    public Double getDescuentototal() {
        return descuentototal;
    }

    public boolean isEstadopedido() {
        return estadopedido;
    }

    public Double getTotal() {
        return total;
    }
// =====================================================
    /*
    //FALTA ESTO
    //HACER UPDATE EN LA BASE DE DATOS del estado del pedido

    public Factura cerrarPedido() {
        Factura factura = new Factura(usuario, this.idpedido, descuentos, impuestos, descuentototal, impuestostotales, total);
        for (Producto producto : productos) {
            factura.agregarProducto(producto,1);
        }
        this.estadopedido = false;
        //HACER UPDATE EN LA BASE DE DATOS del estado del pedido
        return factura;
    }

    */
    // =====================================================

}
