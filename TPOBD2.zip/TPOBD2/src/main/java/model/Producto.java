package model;

import com.mongodb.*;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import database.MongoDBConnection;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.Date;

public class Producto {
    private ObjectId id;

    private Date fechaCreacion;
    private String nombre;
    private Double precio;

    private String foto;

    private String comentarios;
    private String videos;

    private int stock;

    // constructor
    public Producto(String nombre, Double precio, int stock, String foto, String comentarios, String videos) {
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
        this.foto = foto;
        this.comentarios = comentarios;
        this.videos = videos;
        this.fechaCreacion = new Date();
        crearProducto();
    }

    public void crearProducto() {
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> productos = database.getCollection("productos");
        Document doc = new Document("nombre", this.nombre)
                .append("precio", this.precio)
                .append("stock", this.stock)
                .append("precio", this.stock)
                .append("fechacreacion", this.fechaCreacion)
                .append("foto", this.foto)
                .append("video", this.videos)
                .append("comentarios", this.comentarios);
        productos.insertOne(doc);
        this.id = (ObjectId) doc.get("_id");
    }
    public void actualizarProducto() {
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> productos = database.getCollection("productos");
        productos.updateOne(new BasicDBObject("_id", this.id),
                new BasicDBObject("$set",  new BasicDBObject("nombre", this.nombre)
                        .append("precio", this.precio)));
    }

    public void eliminarProducto() {
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> productos = database.getCollection("productos");
        productos.deleteOne(Filters.eq("id", this.getId()));
    }

    public void setnombre(String nombre) {
        this.nombre = nombre;
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> productos = database.getCollection("productos");
        productos.updateOne(new BasicDBObject("_id", this.id),
                new BasicDBObject("$set",  new BasicDBObject("nombre", this.nombre)
                        .append("nombre", this.nombre)));
    }
    public void setPrecio(Double precio) {
        this.precio = precio;
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> productos = database.getCollection("productos");
        productos.updateOne(new BasicDBObject("_id", this.id),
                new BasicDBObject("$set",  new BasicDBObject("nombre", this.nombre)
                        .append("precio", this.precio)));
    }
    public void setstock(int stock) {
        this.stock = stock;
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> productos = database.getCollection("productos");
        productos.updateOne(new BasicDBObject("_id", this.id),
                new BasicDBObject("$set",  new BasicDBObject("nombre", this.nombre)
                        .append("precio", this.stock)));
    }
    public void setFoto(String foto) {
        this.foto = foto;
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> productos = database.getCollection("productos");
        productos.updateOne(new BasicDBObject("_id", this.id),
                new BasicDBObject("$set",  new BasicDBObject("nombre", this.nombre)
                        .append("foto", this.foto)));
    }
    public void setVideos(String videos) {
        this.videos = videos;
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> productos = database.getCollection("productos");
        productos.updateOne(new BasicDBObject("_id", this.id),
                new BasicDBObject("$set",  new BasicDBObject("nombre", this.nombre)
                        .append("foto", this.videos)));
    }
    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> productos = database.getCollection("productos");
        productos.updateOne(new BasicDBObject("_id", this.id),
                new BasicDBObject("$set",  new BasicDBObject("nombre", this.nombre)
                        .append("comentarios", this.comentarios)));
    }
    public int getStock() {
        return stock;
    }

    // getters
    public ObjectId getId() {
        return this.id;
    }

    public String getNombre() {
        return this.nombre;
    }

    public Double getPrecio() {
        return this.precio;
    }

    public String getFoto() {
        return foto;
    }
    public String getComentarios() {
        return comentarios;
    }
    public String getVideos() {
        return videos;
    }



}
