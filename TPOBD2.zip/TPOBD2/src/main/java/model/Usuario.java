package model;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import database.MongoDBConnection;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.ArrayList;

public class Usuario {
    private ObjectId id;
    private String nombre;
    private String username;
    private String password;
    private String direccion;
    ArrayList<LogActividades> actividad = new ArrayList();
    ArrayList<Pedido> pedidos = new ArrayList();
    ArrayList<Factura> facturas = new ArrayList();
    ArrayList<Pago> pagos = new ArrayList();

    private String dni;

    // Constructor
    public Usuario(String username, String password, String nombre, String dni, String direccion) {
        this.username = username;
        this.password = password;
        this.dni = dni;
        this.nombre = nombre;
        this.direccion = direccion;
        crearUsuario();
    }
    public void crearUsuario() {
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> usuarios = database.getCollection("usuarios");
        Document doc = new Document("nombre", this.nombre)
                .append("username", this.username)
                .append("password", this.password)
                .append("dni", this.dni)
                .append("direccion", this.direccion);
        usuarios.insertOne(doc);
        this.id = (ObjectId) doc.get("_id");
    }
    public void eliminarUsuario() {
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> usuarios = database.getCollection("usuarios");
        usuarios.deleteOne(Filters.eq("id", this.getId()));
    }

    // setters
    public void setUsername(String username) {
        this.username = username;
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> usuarios = database.getCollection("usuarios");
        usuarios.updateOne(new BasicDBObject("_id", this.id),
                new BasicDBObject("$set",  new BasicDBObject("nombre", this.nombre)
                        .append("username", this.username)));
    }
    public void setPassword(String password) {
        this.password = password;
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> usuarios = database.getCollection("usuarios");
        usuarios.updateOne(new BasicDBObject("_id", this.id),
                new BasicDBObject("$set",  new BasicDBObject("nombre", this.nombre)
                        .append("password", this.password)));
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> usuarios = database.getCollection("usuarios");
        usuarios.updateOne(new BasicDBObject("_id", this.id),
                new BasicDBObject("$set",  new BasicDBObject("nombre", this.nombre)
                        .append("nombre", this.nombre)));
    }
    public void setDni(String dni) {
        this.dni = dni;
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> usuarios = database.getCollection("usuarios");
        usuarios.updateOne(new BasicDBObject("_id", this.id),
                new BasicDBObject("$set",  new BasicDBObject("nombre", this.nombre)
                        .append("dni", this.dni)));
    }
    public void setDireccion(String direccion) {
        this.direccion = direccion;
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> usuarios = database.getCollection("usuarios");
        usuarios.updateOne(new BasicDBObject("_id", this.id),
                new BasicDBObject("$set",  new BasicDBObject("nombre", this.nombre)
                        .append("dni", this.direccion)));
    }

    public void agregarActividad(String operacion, String accion, String valoranterior,String nuevoValor, String tipoobjeString, ObjectId idreferenciaobjeto) {
    LogActividades nuevaactividad = new LogActividades(operacion, accion, valoranterior, nuevoValor, this,tipoobjeString,idreferenciaobjeto);
    actividad.add(0, nuevaactividad);
    }

    public void agregarPedido(Pedido pedido){
        pedidos.add(pedido);
    }

    public void agregarPedido(Pago pago){
        pagos.add(pago);
    }
    public void agregarPedido(Factura factura){
        facturas.add(factura);
    }

    public void listadoDePagos(){
        for (Pago pago : pagos) {
            System.out.println("Fecha: " + pago.getFecha() + "importe: " + pago.getMonto() + "medio de pago: " + pago.getMediodepago() + "Factura afectada: " +pago.getIdfactura());
            }
    }
    public void listadoDePedidos(){
        for (Pedido pedido : pedidos) {
            System.out.println("Fecha: " + pedido.getFecha() + "importe: " + pedido.getTotal());
        }
    }
    public void listadoDeFacturas(){
        for (Factura factura : facturas) {
            System.out.println("Fecha: " + factura.getFecha() + "importe: " + factura.getTotal());
        }
    }

    public ObjectId getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getDni() {
        return dni;
    }
}
