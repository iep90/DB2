package model;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import database.MongoDBConnection;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.Date;

public class CarritoDeCompras {
    private ObjectId idcarrito;
    private Usuario usuario;
    private Date fecha;
    private boolean estadoCarrito;
    ArrayList<Producto> productos = new ArrayList();

    // Constructor
    public CarritoDeCompras(Usuario usuario) {
        this.usuario = usuario;
        this.fecha = new Date();
        this.estadoCarrito = true;
        crearCarrito();
    }

    public void crearCarrito() {
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> carritos = database.getCollection("carritos");
        Document doc = new Document("usuario", usuario.getNombre())
                .append("fecha", this.fecha)
                .append("estadocarrito", this.estadoCarrito);
        carritos.insertOne(doc);
        this.idcarrito = (ObjectId) doc.get("_id");
    }

    public String consultarDuenoCarrito(){
        return this.usuario.getNombre();
    }

    public void listarProductosCarrito(){
        for (Producto producto : productos) {
            System.out.printf("Nombre: "+producto.getNombre()+" - Precio: "+producto.getPrecio());
        }
    }

    public void ingresarProducto(Producto productonuevo, int cantidad) {
        for (Producto producto : productos) {
            if (producto.getId() == productonuevo.getId() && producto.getStock() >= cantidad) {
                    producto.setstock(producto.getStock() - cantidad);
                    MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
                    MongoCollection<Document> carritos = database.getCollection("carritosdetalle");
                    Document doc = new Document("idcarrito", this.idcarrito)
                            .append("fecha",new Date())
                            .append("cantidad", cantidad)
                            .append("idproducto", productonuevo.getId())
                            .append("precio", productonuevo.getPrecio() * cantidad)
                            .append("producto", productonuevo);
                    carritos.insertOne(doc);
                    productos.add(productonuevo);
                    break;
                }else{
                System.out.println("El producto no tiene suficiente stock");
            }
            }
        }
    public void eliminarProducto(Producto producto) {
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> carritos = database.getCollection("carritosdetalle");
        carritos.deleteOne(Filters.and(Filters.eq("idproducto", producto.getId()),Filters.eq("idcarrito",idcarrito)));
        productos.remove(producto);
    }
    public Producto obtenerProductoPorNombre(String nombre){
        Producto productotoReturn = null;
        for (Producto producto : productos) {
            if (producto.getNombre() == nombre) {
                productotoReturn = producto;
                break;
            }
        }
        return(productotoReturn);
    }

    public void actualizarCantidad(ObjectId idcarrito, ObjectId idproducto, int cantidad) {
        for (Producto producto : productos) {
            if (producto.getId() == idproducto) {
                if(producto.getStock() >= cantidad){
                    producto.setstock(producto.getStock() - cantidad);
                    /* FALTA ACTUALIZAR EN LA DB
                    // cambiar tambien precio = precio * cantidad nueva
                    MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
                    MongoCollection<Document> carritos = database.getCollection("carritosdetalle");
                    carritos.updateOne(new BasicDBObject("_id", idproducto,
                            new BasicDBObject("$set",  new BasicDBObject("cantidad", cantidad)
                                    .append("precio", this.precio)));

                    */
                    break;

                }else{
                    System.out.println("El producto no tiene suficiente stock");
                }

            }
        }
    }
    public Pedido confirmarCarrito(){
        Pedido pedido = new Pedido(usuario, this.idcarrito);
        for (Producto producto : productos) {
            pedido.agregarProducto(producto,1);
        }
        return pedido;
        //FALTA MIRAR ABAJO
    }




    // =====================================================
    /*
    //FALTA ESTO
    //HACER UPDATE EN LA BASE DE DATOS del estado del pedido

    public Pedido confirmarCarrito(){
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> carritodetalle = database.getCollection("carritosdetalle");
        int cantidad = carritodetalle.find(Filters.and(Filters.eq("idproducto", producto.getId()),Filters.eq("idcarrito",idcarrito)));

        Pedido pedido = new Pedido(usuario, this.idcarrito);
        FindIterable<Document> documents = carritodetalle.find(filter);

        for (Producto producto : productos) {
            pedido.agregarProducto(producto,1);
        }
        //falta funcion para cambiar estado a "
         this.estadoCarrito = true;

        return pedido;

    }
    */
    // =====================================================

    public ObjectId getIdcarrito() {
        return idcarrito;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public Date getFecha() {
        return fecha;
    }

    public boolean isEstadoCarrito() {
        return estadoCarrito;
    }

    public ArrayList<Producto> getProductos() {
        return productos;
    }
}
