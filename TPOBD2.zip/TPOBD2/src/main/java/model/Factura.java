package model;

import com.mongodb.*;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import database.MongoDBConnection;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.Date;

public class Factura {
    private ObjectId idfactura;
    private ObjectId idpedido;
    private Usuario usuario;

    private double neto;
    private double total;

    private Date fecha;

    private boolean estadopagofactura;
    ArrayList<Producto> productos = new ArrayList();

    ArrayList<Pago> pagos = new ArrayList();


    ArrayList<Double> descuentos = new ArrayList();

    ArrayList<Double> impuestos = new ArrayList();

    private Double impuestostotales;
    private Double descuentototal;

    private boolean estadopedido;


    // constructor
    public Factura(Usuario usuario, ObjectId idPedido, ArrayList<Double> descuentos,ArrayList<Double> impuestos, Double descuentostotales, Double impuestostotales, Double total ) {
        this.idpedido = idPedido;
        this.usuario = usuario;
        this.estadopagofactura = false;
        this.fecha = new Date();
        this.impuestostotales = impuestostotales;
        this.descuentototal = descuentostotales;
        this.impuestos = impuestos;
        this.descuentos = descuentos;
        this.total = total;
        this.neto = total - impuestostotales + descuentostotales;
        crearFactura();
    }


    public void crearFactura() {
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> facturas = database.getCollection("facturas");
        Document doc = new Document("usuario", this.usuario)
                .append("fecha", this.fecha)
                .append("impuestostotales", this.impuestostotales)
                .append("descuentototal", this.descuentototal)
                .append("total", this.total)
                .append("neto", this.neto)
                .append("estadopagofactura", this.estadopagofactura);
        facturas.insertOne(doc);
        this.idfactura = (ObjectId) doc.get("_id");
    }
    public void agregarProducto(Producto productonuevo, int cantidad) {
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> facturasdetalle = database.getCollection("facturasdetalle");
        Document doc = new Document("idfactura", this.idfactura)
                .append("fecha",new Date())
                .append("cantidad", cantidad)
                .append("idproducto", productonuevo.getId())
                .append("neto", productonuevo.getPrecio() * cantidad)
                .append("impuesto", productonuevo.getPrecio() * 021)
                .append("total", productonuevo.getPrecio() + productonuevo.getPrecio() * 021)
                .append("producto", productonuevo);
        facturasdetalle.insertOne(doc);
        productos.add(productonuevo);
    }
    public void eliminarProducto(ObjectId idfactura, Producto producto) {
        MongoDatabase database = MongoDBConnection.getConnection().getDatabase("test");
        MongoCollection<Document> pedidosdetalle = database.getCollection("pedidosdetalle");
        pedidosdetalle.deleteOne(Filters.and(Filters.eq("idproducto", producto.getId()),Filters.eq("idfactura",idfactura)));
        productos.remove(producto);
    }
    public Producto obtenerProductoPorNombre(String nombre){
        Producto productotoReturn = null;
        for (Producto producto : productos) {
            if (producto.getNombre() == nombre) {
                productotoReturn = producto;
                break;
            }
        }
        return(productotoReturn);
    }

    public void generarPago(String mediodepago){
        Pago nuevopago = new Pago(usuario, total, mediodepago, idfactura);
        pagos.add(nuevopago);
        this.estadopagofactura = true;
    }

    public void setEstadopagofactura(boolean estadopagofactura) {
        this.estadopagofactura = estadopagofactura;
    }

    public ObjectId getIdfactura() {
        return idfactura;
    }

    public ObjectId getIdpedido() {
        return idpedido;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public double getNeto() {
        return neto;
    }

    public double getTotal() {
        return total;
    }

    public Date getFecha() {
        return fecha;
    }

    public boolean isEstadopagofactura() {
        return estadopagofactura;
    }

    public ArrayList<Producto> getProductos() {
        return productos;
    }

    public ArrayList<Pago> getPagos() {
        return pagos;
    }

    public ArrayList<Double> getDescuentos() {
        return descuentos;
    }

    public ArrayList<Double> getImpuestos() {
        return impuestos;
    }

    public Double getImpuestostotales() {
        return impuestostotales;
    }

    public Double getDescuentototal() {
        return descuentototal;
    }

    public boolean isEstadopedido() {
        return estadopedido;
    }
}
