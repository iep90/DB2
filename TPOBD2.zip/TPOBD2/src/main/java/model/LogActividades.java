package model;
import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.api.core.cql.ResultSet;
import com.datastax.oss.driver.api.core.cql.Row;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import database.CassandraConnection;
import database.MongoDBConnection;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.Date;

public class LogActividades {
    private ObjectId idoperacion;
    private String operacion;
    private String valoranterior;
    private String nuevoValor;
    private ObjectId idusuario;
    private Date fecha;
    private String accion;
    private Usuario usuario;
    private ObjectId idreferenciaobjeto;
    private String tipoobjeto;


    // constructor
    public LogActividades(String operacion, String accion, String valoranterior,String nuevoValor, Usuario usuario, String tipoobjeto, ObjectId idreferenciaobjeto) {
        this.fecha = new Date();
        this.usuario = usuario;
        this.operacion = operacion;
        this.accion = accion;
        this.nuevoValor = nuevoValor;
        this.usuario = usuario;
        this.valoranterior = valoranterior;
        this.idreferenciaobjeto = idreferenciaobjeto;
        this.tipoobjeto = tipoobjeto;
        this.idreferenciaobjeto = idreferenciaobjeto;
        registrarActividad(this.operacion, this.accion, this.valoranterior,this.nuevoValor, this.usuario, this.tipoobjeto, this.idreferenciaobjeto);
    }

    public void registrarActividad(String operacion, String accion, String valoranterior,String nuevoValor, Usuario usuario,String tipoobjeto, ObjectId idreferenciaobjeto) {
        CassandraConnection session = new CassandraConnection();   
        session.connect();
        StringBuilder sb = new StringBuilder("INSERT INTO")
        .append("log").append("(Idoperador,fecha, operacion, accion, valoranterior, valornuevo,usuarioId, usuario, tipoobjeto, referenciaobjeto)")
        .append("VALUES (").append(idoperacion)
        .append(", '").append(this.fecha)
        .append(", '").append(operacion)
        .append(", '").append(accion)
        .append(", '").append(valoranterior)
        .append(", '").append(nuevoValor)
        .append(", '").append(idusuario)
        .append(", '").append(usuario)
        .append(", '").append(tipoobjeto)
        .append(", '").append(idreferenciaobjeto)
        .append("');'");
        String query = sb.toString();
        session.execute((CqlSession) session,query);
    }

}
