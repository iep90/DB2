import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.api.core.CqlSessionBuilder;
import com.datastax.oss.driver.api.core.CqlSessionBuilderBase;
import com.datastax.oss.driver.api.core.CqlSessionBuilder.DefaultSslEngineFactory;
import com.datastax.oss.driver.api.core.CqlSessionBuilder.SslEngineFactory;
import com.datastax.oss.driver.api.core.config.DriverConfigLoader;
import com.datastax.oss.driver.api.core.config.DriverOption;

public class CassandraDataContext implements IConnection<CqlSession> {
    private CqlSession session;

    public CassandraDataContext(IConfiguration configuration) {
        String cloudSecureConnectionBundlePath = "C:\\Users\\gonza\\Documents\\Programacion\\secure-connect-e-commerce-bd2.zip";
        String clientId = configuration.getValue("Databases:Cassandra:ClientID");
        String clientSecret = configuration.getValue("Databases:Cassandra:ClientSecret");
        String keyspace = configuration.getValue("Databases:Cassandra:KeySpace");

        CqlSessionBuilder builder = CqlSession.builder();
        builder.withConfigLoader(DriverConfigLoader.fromClasspath("application.conf"));
        builder.addContactPoint("127.0.0.1");

        SslEngineFactory sslEngineFactory = new DefaultSslEngineFactory();
        builder.withSslEngineFactory(sslEngineFactory);
        builder.withCloudSecureConnectBundle(cloudSecureConnectionBundlePath);

        builder.withAuthCredentials(clientId, clientSecret);
        builder.withKeyspace(keyspace);

        session = builder.build();
    }

    public CqlSession getConnection() {
        return session;
    }
}
