public interface IConnection<T> {
    T getConnection();
}
