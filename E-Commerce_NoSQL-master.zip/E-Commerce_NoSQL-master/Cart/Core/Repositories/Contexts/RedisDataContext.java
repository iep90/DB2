import io.lettuce.core.RedisClient;
import io.lettuce.core.RedisURI;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.api.sync.RedisCommands;

public class RedisDataContext implements IConnection<RedisCommands<String, String>> {
    private RedisCommands<String, String> connection;

    public RedisDataContext(IConfiguration configuration) {
        String connectionString = configuration.getValue("Databases:Redis:ConnectionString");

        RedisURI redisUri = RedisURI.create(connectionString);
        RedisClient redisClient = RedisClient.create(redisUri);
        StatefulRedisConnection<String, String> redisConnection = redisClient.connect();

        connection = redisConnection.sync();
    }

    public RedisCommands<String, String> getConnection() {
        return connection;
    }
}
