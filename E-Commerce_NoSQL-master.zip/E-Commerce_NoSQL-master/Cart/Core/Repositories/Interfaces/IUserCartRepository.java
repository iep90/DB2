import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public interface IUserCartRepository {
    CompletableFuture<Void> changeUserCartAsync(UserCartDTO userCartInfo);

    CompletableFuture<List<UserActivityDTO>> getUserActivityAsync(UUID userId);

    CompletableFuture<UserCartDTO> getUserCartAsync(UUID userId);

    CompletableFuture<Void> restoreCart(UUID userId, UUID logId);

    CompletableFuture<Void> emptyCart(UUID userId);
}
