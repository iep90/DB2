import Cart.Core.DataTransferObjects.UserActivityDTO;
import Cart.Core.DataTransferObjects.UserCartDTO;
import Cart.Core.Repositories.Contexts.Interfaces.IConnection;
import Cart.Core.Repositories.Interfaces.IUserCartRepository;
import com.datastax.oss.driver.api.core.CqlIdentifier;
import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.api.core.cql.BoundStatement;
import com.datastax.oss.driver.api.core.cql.PreparedStatement;
import com.datastax.oss.driver.api.core.cql.ResultSet;
import com.datastax.oss.driver.api.core.cql.Row;
import io.lettuce.core.api.async.RedisAsyncCommands;
import io.lettuce.core.api.sync.RedisCommands;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.api.StatefulRedisConnectionImpl;
import io.lettuce.core.cluster.ClusterClientOptions;
import io.lettuce.core.cluster.RedisClusterClient;
import io.lettuce.core.cluster.api.async.RedisAdvancedClusterAsyncCommands;
import io.lettuce.core.cluster.api.sync.RedisAdvancedClusterCommands;
import io.lettuce.core.cluster.api.sync.RedisClusterCommands;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public class UserCartRepository implements IUserCartRepository {
    private final IConnection<RedisCommands<String, String>> redisConnection;
    private final IConnection<CqlSession> cassandraConnection;

    public UserCartRepository(IConnection<RedisCommands<String, String>> redisConnection,
                              IConnection<CqlSession> cassandraConnection) {
        this.redisConnection = redisConnection;
        this.cassandraConnection = cassandraConnection;
    }

    @Override
    public CompletableFuture<Void> changeUserCartAsync(UserCartDTO info) {
        UUID processId = UUID.randomUUID();
        UUID userId = info.getUser().getUserId();
        RedisCommands<String, String> redisCommands = redisConnection.getConnection();
        RedisAdvancedClusterCommands<String, String> redisClusterCommands =
                ((StatefulRedisConnectionImpl<String, String>) redisConnection.getConnection()).getSync();
        CqlSession cqlSession = cassandraConnection.getConnection();

        redisCommands.hmset("user:" + userId, info.getUser().toHashEntries());

        List<String> userProductsId = redisCommands.smembers("userCart:" + userId);

        for (String product : userProductsId) {
            if (!info.getProducts().stream()
                    .anyMatch(pr -> pr.getProductCatalogId().toString().equals(product))) {
                redisCommands.srem("userCart:" + userId, product);
            }
        }

        for (ProductCartDTO product : info.getProducts()) {
            String productKey = "userCart:" + userId + ":" + product.getProductCatalogId();
            redisCommands.hmset(productKey, product.toHashEntries());

            PreparedStatement preparedStatement = cqlSession.prepare(
                    "INSERT INTO cart (id, moment, userId, imageurl, price, productcatalogid, productname, quantity) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            BoundStatement boundStatement = preparedStatement.bind(processId, java.time.Instant.now(), userId,
                    product.getImageURL(), product.getPrice(), product.getProductCatalogId(),
                    product.getProductName(), product.getQuantity());
            cqlSession.execute(boundStatement);

            redisCommands.sadd("userCart:" + userId, product.getProductCatalogId().toString());
        }

        return CompletableFuture.completedFuture(null);
    }

    @Override
    public CompletableFuture<UserCartDTO> getUserCartAsync(UUID userId) {
        RedisCommands<String, String> redisCommands = redisConnection.getConnection();
        UserCartDTO result = new UserCartDTO();

        List<String> userInfo = redisCommands.hgetall("user:" + userId);
        if (userInfo.isEmpty()) {
            return CompletableFuture.completedFuture(null);
        }

        result.addUserData(userId, userInfo);

        List<String> userProductsId = redisCommands.smembers("userCart:" + userId);

        for (String productCartId : userProductsId) {
            List<String> productInfo = redisCommands.hgetall("userCart:" + userId + ":" + productCartId);
            result.addProductData(UUID.fromString(productCartId), productInfo);
        }

        return CompletableFuture.completedFuture(result);
    }

    @Override
    public CompletableFuture<List<UserActivityDTO>> getUserActivityAsync(UUID userId) {
        CqlSession cqlSession = cassandraConnection.getConnection();
        List<UserActivityDTO> result = new ArrayList<>();

        PreparedStatement preparedStatement = cqlSession.prepare("SELECT * FROM cart WHERE userId = ?");
        BoundStatement boundStatement = preparedStatement.bind(userId);
        ResultSet resultSet = cqlSession.execute(boundStatement);

        for (Row row : resultSet) {
            result.add(new UserActivityDTO(row));
        }

        return CompletableFuture.completedFuture(result);
    }

    @Override
    public CompletableFuture<Void> restoreCart(UUID userId, UUID logId) {
        UUID processId = UUID.randomUUID();
        List<String> productsCatalogId = new ArrayList<>();
        CqlSession cqlSession = cassandraConnection.getConnection();
        RedisCommands<String, String> redisCommands = redisConnection.getConnection();
        RedisAdvancedClusterCommands<String, String> redisClusterCommands =
                ((StatefulRedisConnectionImpl<String, String>) redisConnection.getConnection()).getSync();

        ResultSet queryResult = cqlSession.execute("SELECT * FROM cart WHERE id = ?", logId);
        for (Row row : queryResult) {
            ProductCartDTO product = new ProductCartDTO(row);
            productsCatalogId.add(product.getProductCatalogId().toString());

            String productKey = "userCart:" + userId + ":" + product.getProductCatalogId();
            redisCommands.hmset(productKey, product.toHashEntries());

            redisCommands.sadd("userCart:" + userId, product.getProductCatalogId().toString());

            PreparedStatement preparedStatement = cqlSession.prepare(
                    "INSERT INTO cart (id, moment, userId, imageurl, price, productcatalogid, productname, quantity) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            BoundStatement boundStatement = preparedStatement.bind(processId, java.time.Instant.now(), userId,
                    product.getImageURL(), product.getPrice(), product.getProductCatalogId(),
                    product.getProductName(), product.getQuantity());
            cqlSession.execute(boundStatement);
        }

        List<String> userProductsId = redisCommands.smembers("userCart:" + userId);
        for (String product : userProductsId) {
            if (!productsCatalogId.contains(product)) {
                redisCommands.srem("userCart:" + userId, product);
            }
        }

        return CompletableFuture.completedFuture(null);
    }

    @Override
    public CompletableFuture<Void> emptyCart(UUID userId) {
        RedisCommands<String, String> redisCommands = redisConnection.getConnection();
        RedisAdvancedClusterCommands<String, String> redisClusterCommands =
                ((StatefulRedisConnectionImpl<String, String>) redisConnection.getConnection()).getSync();

        List<String> userProductsId = redisCommands.smembers("userCart:" + userId);

        if (userProductsId.isEmpty()) {
            throw new Exception("Cart is empty");
        }

        for (String product : userProductsId) {
            redisCommands.srem("userCart:" + userId, product);
        }

        return CompletableFuture.completedFuture(null);
    }
}
