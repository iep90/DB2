import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public interface IUserCartService {
    CompletableFuture<UserCartDTO> getUserCartAsync(UUID userId);

    CompletableFuture<List<UserActivityDTO>> getUserActivityAsync(UUID userId);

    CompletableFuture<Void> changeUserCart(UserCartDTO userCartInfo);

    CompletableFuture<Void> restoreCart(UUID userId, UUID logId);

    CompletableFuture<Void> checkout(UUID userId);
}
