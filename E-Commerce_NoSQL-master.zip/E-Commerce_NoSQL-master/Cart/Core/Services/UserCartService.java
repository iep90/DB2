package Cart.Core.Services;

import Cart.Core.DataTransferObjects.UserActivityDTO;
import Cart.Core.DataTransferObjects.UserCartDTO;
import Cart.Core.Repositories.Interfaces.IUserCartRepository;
import Cart.Core.Services.Interfaces.IUserCartService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.UUID;

@Service
public class UserCartService implements IUserCartService {

    private final IUserCartRepository userCartRepository;
    private final RestTemplate restTemplate;

    @Autowired
    public UserCartService(IUserCartRepository userCartRepository, RestTemplate restTemplate) {
        this.userCartRepository = userCartRepository;
        this.restTemplate = restTemplate;
    }

    @Override
    public void changeUserCart(UserCartDTO userCartInfo) {
        userCartRepository.changeUserCartAsync(userCartInfo);
    }

    @Override
    public UserCartDTO getUserCart(UUID userId) {
        return userCartRepository.getUserCartAsync(userId).join();
    }

    @Override
    public List<UserActivityDTO> getUserActivity(UUID userId) {
        return userCartRepository.getUserActivityAsync(userId).join();
    }

    @Override
    public void restoreCart(UUID userId, UUID logId) {
        userCartRepository.restoreCart(userId, logId);
    }

    @Override
    public void checkout(UUID userId) {
        UserCartDTO checkoutInfo = userCartRepository.getUserCartAsync(userId).join();
        if (checkoutInfo == null) {
            throw new RuntimeException("Empty cart");
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        ObjectMapper mapper = new ObjectMapper();
        String json;
        try {
            json = mapper.writeValueAsString(checkoutInfo);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error converting checkout info to JSON");
        }
        HttpEntity<String> requestEntity = new HttpEntity<>(json, headers);

        restTemplate.exchange("http://commerce/order", HttpMethod.POST, requestEntity, String.class);

        userCartRepository.emptyCart(userId);
    }
}
