import Cart.Core.DataTransferObjects;
import Cart.Core.Services.Interfaces;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

@RestController
@RequestMapping("/api/usercart")
public class UserCartController {
    private final IUserCartService userCartService;

    public UserCartController(IUserCartService userCartService) {
        this.userCartService = userCartService;
    }

    @GetMapping
    public ResponseEntity<UserCartDTO> getUserCart(@RequestParam("userId") UUID userId) {
        UserCartDTO result = userCartService.getUserCartAsync(userId);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/activity")
    public ResponseEntity<UserActivityDTO> getUserActivity(@RequestParam("userId") UUID userId) {
        UserActivityDTO result = userCartService.getUserActivityAsync(userId);
        return ResponseEntity.ok(result);
    }

    @PostMapping
    public ResponseEntity<Void> changeUserCart(@RequestBody UserCartDTO userCartInfo) {
        userCartService.changeUserCart(userCartInfo);
        return ResponseEntity.noContent().build();
    }

    @PutMapping
    public ResponseEntity<Void> restoreCart(@RequestParam("userId") UUID userId, @RequestParam("logId") UUID logId) {
        userCartService.restoreCart(userId, logId);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/checkout")
    public ResponseEntity<Void> checkout(@RequestParam("userId") UUID userId) {
        userCartService.checkout(userId);
        return ResponseEntity.noContent().build();
    }
}
