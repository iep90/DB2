import com.datastax.driver.core.Row;
import redis.clients.jedis.Jedis;
import java.util.UUID;

public class ProductCartDTO {
    private UUID productCatalogId;
    private String productName;
    private String imageURL;
    private int quantity;
    private double price;

    public ProductCartDTO() {}

    public ProductCartDTO(Row row) {
        productCatalogId = row.getUUID("productcatalogid");
        productName = row.getString("productname");
        imageURL = row.getString("imageurl");
        quantity = row.getInt("quantity");
        price = row.getDouble("price");
    }

    public UUID getProductCatalogId() {
        return productCatalogId;
    }

    public void setProductCatalogId(UUID productCatalogId) {
        this.productCatalogId = productCatalogId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String[] toHashEntries() {
        return new String[]{
                "ProductName", productName,
                "ImageURL", imageURL,
                "Quantity", String.valueOf(quantity),
                "Price", String.valueOf(price)
        };
    }

    public void addHashEntryData(UUID id, String[] entries) {
        productCatalogId = id;
        for (int i = 0; i < entries.length; i += 2) {
            String name = entries[i];
            String value = entries[i + 1];
            switch (name) {
                case "ProductName":
                    productName = value;
                    break;
                case "ImageURL":
                    imageURL = value;
                    break;
                case "Quantity":
                    quantity = Integer.parseInt(value);
                    break;
                case "Price":
                    price = Double.parseDouble(value);
                    break;
                default:
                    break;
            }
        }
    }
}
