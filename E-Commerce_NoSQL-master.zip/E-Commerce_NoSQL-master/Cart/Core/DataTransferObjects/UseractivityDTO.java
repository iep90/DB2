import com.datastax.driver.core.Row;
import java.util.UUID;
import java.time.LocalDateTime;

public class UserActivityDTO {
    private UUID id;
    private LocalDateTime moment;
    private UUID userId;
    private String imageUrl;
    private double price;
    private UUID productCatalogId;
    private String productName;
    private int quantity;

    public UserActivityDTO() {}

    public UserActivityDTO(Row row) {
        id = row.getUUID("id");
        moment = row.getTimestamp("moment").toLocalDateTime();
        userId = row.getUUID("userid");
        imageUrl = row.getString("imageurl");
        price = row.getDouble("price");
        productCatalogId = row.getUUID("productcatalogid");
        productName = row.getString("productname");
        quantity = row.getInt("quantity");
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public LocalDateTime getMoment() {
        return moment;
    }

    public void setMoment(LocalDateTime moment) {
        this.moment = moment;
    }

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public UUID getProductCatalogId() {
        return productCatalogId;
    }

    public void setProductCatalogId(UUID productCatalogId) {
        this.productCatalogId = productCatalogId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
