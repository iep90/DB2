import redis.clients.jedis.Jedis;
import java.util.UUID;

public class UserDTO {
    private UUID userId;
    private String name;
    private String lastName;
    private String address;

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String[] toHashEntries() {
        return new String[]{
                "Name", name,
                "LastName", lastName,
                "Address", address
        };
    }

    public void addHashEntryData(UUID id, String[] entries) {
        userId = id;
        for (int i = 0; i < entries.length; i += 2) {
            String name = entries[i];
            String value = entries[i + 1];
            switch (name) {
                case "Name":
                    this.name = value;
                    break;
                case "LastName":
                    lastName = value;
                    break;
                case "Address":
                    address = value;
                    break;
                default:
                    break;
            }
        }
    }
}
