import redis.clients.jedis.Jedis;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class UserCartDTO {
    private UserDTO user;
    private List<ProductCartDTO> products;

    public UserCartDTO() {
        products = new ArrayList<>();
    }

    public UserDTO getUser() {
        return user;
    }

    public void setUser(UserDTO user) {
        this.user = user;
    }

    public List<ProductCartDTO> getProducts() {
        return products;
    }

    public void setProducts(List<ProductCartDTO> products) {
        this.products = products;
    }

    public void addUserData(UUID id, String[] entries) {
        user = new UserDTO();
        user.addHashEntryData(id, entries);
    }

    public void addProductData(UUID id, String[] entries) {
        ProductCartDTO product = new ProductCartDTO();
        product.addHashEntryData(id, entries);
        products.add(product);
    }
}
