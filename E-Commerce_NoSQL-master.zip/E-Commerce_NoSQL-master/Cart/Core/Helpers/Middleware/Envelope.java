import java.time.LocalDateTime;

public final class Envelope extends Envelope<String> {
    private Envelope(String errorMessage) {
        super(null, errorMessage);
    }

    public static <T> Envelope<T> ok(T result) {
        return new Envelope<>(result, null);
    }

    public static Envelope ok() {
        return new Envelope(null);
    }

    public static Envelope error(String errorMessage) {
        return new Envelope(errorMessage);
    }
}

public class Envelope<T> {
    protected Envelope(T result, String errorMessage) {
        Result = result;
        ErrorMessage = errorMessage;
        TimeGenerated = LocalDateTime.now();
    }

    public T Result;
    public String ErrorMessage;
    public LocalDateTime TimeGenerated;
}
