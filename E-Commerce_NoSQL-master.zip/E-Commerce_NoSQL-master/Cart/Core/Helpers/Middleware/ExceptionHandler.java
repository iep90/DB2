import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.util.StdDateFormat;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.StatusCodes;

import java.util.logging.Level;
import java.util.logging.Logger;

public class ExceptionHandler implements HttpHandler {
    private final HttpHandler nextHandler;
    private final ObjectMapper objectMapper;

    public ExceptionHandler(HttpHandler nextHandler) {
        this.nextHandler = nextHandler;
        this.objectMapper = new ObjectMapper();
        this.objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        this.objectMapper.setDateFormat(new StdDateFormat());
    }

    @Override
    public void handleRequest(HttpServerExchange exchange) throws Exception {
        try {
            nextHandler.handleRequest(exchange);
        } catch (Exception exception) {
            sendPayload(exchange, Envelope.error(exception.getMessage()));
        }
    }

    private void sendPayload(HttpServerExchange exchange, Object payload, int statusCode) {
        try {
            String result = objectMapper.writeValueAsString(payload);
            exchange.getResponseHeaders().put("Content-Type", "application/json");
            exchange.setStatusCode(statusCode);
            exchange.getResponseSender().send(result);
        } catch (JsonProcessingException e) {
            Logger.getLogger(ExceptionHandler.class.getName()).log(Level.SEVERE, "Error serializing payload", e);
        }
    }
}
