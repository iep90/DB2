import Cart.Core.Contexts.RedisDataContext;
import Cart.Core.Contexts.CassandraDataContext;
import Cart.Core.Repositories.Contexts.IConnection;
import Cart.Core.Repositories.Contexts.RedisDataContext;
import Cart.Core.Repositories.Contexts.CassandraDataContext;
import Cart.Core.Repositories.Interfaces.IUserCartRepository;
import Cart.Core.Repositories.UserCartRepository;
import Cart.Core.Services.Interfaces.IUserCartService;
import Cart.Core.Services.UserCartService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public IConnection<IDatabase> redisConnection() {
        return new RedisDataContext();
    }

    @Bean
    public IConnection<ISession> cassandraConnection() {
        return new CassandraDataContext();
    }

    @Bean
    public IUserCartRepository userCartRepository(IConnection<IDatabase> redisConnection, IConnection<ISession> cassandraConnection) {
        return new UserCartRepository(redisConnection, cassandraConnection);
    }

    @Bean
    public IUserCartService userCartService(IUserCartRepository userCartRepository) {
        return new UserCartService(userCartRepository);
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
