import java.util.List;
import java.util.UUID;

public class OrderDTO {
    private UUID userId;
    private List<ProductCartDTO> products;
    private boolean iva;

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public List<ProductCartDTO> getProducts() {
        return products;
    }

    public void setProducts(List<ProductCartDTO> products) {
        this.products = products;
    }

    public boolean isIva() {
        return iva;
    }

    public void setIva(boolean iva) {
        this.iva = iva;
    }
}
