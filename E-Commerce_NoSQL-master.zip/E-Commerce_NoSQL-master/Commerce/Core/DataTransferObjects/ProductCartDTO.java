import java.util.UUID;

public class ProductCartDTO {
    private UUID productCatalogId;
    private int quantity;

    public UUID getProductCatalogId() {
        return productCatalogId;
    }

    public void setProductCatalogId(UUID productCatalogId) {
        this.productCatalogId = productCatalogId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
