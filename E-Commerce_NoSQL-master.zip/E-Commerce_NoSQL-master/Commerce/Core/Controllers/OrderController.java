import Commerce.Core.DataTransferObjects.OrderDTO;
import Commerce.Core.Models.Order;
import Commerce.Core.Services.Interfaces.IOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/order")
public class OrderController {

    private final IOrderService orderService;

    @Autowired
    public OrderController(IOrderService orderService) {
        this.orderService = orderService;
    }

    @GetMapping
    public ResponseEntity<?> getAllOrders() {
        return ResponseEntity.ok(orderService.getAllOrders());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getOrderById(@PathVariable("id") UUID id) {
        return ResponseEntity.ok(orderService.getOrderById(id));
    }

    @GetMapping("/status")
    public ResponseEntity<?> getOrderByStatus(@RequestParam("status") boolean status) {
        return ResponseEntity.ok(orderService.getOrderByStatus(status));
    }

    @PostMapping
    public ResponseEntity<?> createOrder(@RequestBody OrderDTO order) {
        if (order == null) {
            return ResponseEntity.badRequest().build();
        }

        orderService.insertOrder(order);

        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteOrder(@PathVariable("id") UUID id) {
        orderService.deleteOrder(id);
        return ResponseEntity.noContent().build();
    }
}
