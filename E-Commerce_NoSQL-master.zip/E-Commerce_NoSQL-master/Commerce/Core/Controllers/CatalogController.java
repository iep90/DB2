import Commerce.Core.DataTransferObjects.ProductCatalogDTO;
import Commerce.Core.Models.ProductCatalog;
import Commerce.Core.Services.Interfaces.ICatalogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/catalog")
public class CatalogController {

    private final ICatalogService catalogService;

    @Autowired
    public CatalogController(ICatalogService catalogService) {
        this.catalogService = catalogService;
    }

    @GetMapping
    public ResponseEntity<?> getCatalog() {
        return ResponseEntity.ok(catalogService.getAllProductsCatalog());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getProductCatalogById(@PathVariable("id") UUID id) {
        return ResponseEntity.ok(catalogService.getProductCatalogById(id));
    }

    @GetMapping("/log/{id}")
    public ResponseEntity<?> getProductCatalogLogById(@PathVariable("id") UUID id) {
        return ResponseEntity.ok(catalogService.getProductCatalogLogById(id));
    }

    @PostMapping
    public ResponseEntity<?> insertProductCatalog(@RequestBody ProductCatalogDTO catalog) {
        if (catalog == null) {
            return ResponseEntity.badRequest().build();
        }

        catalogService.insertProductCatalog(catalog);

        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping
    public ResponseEntity<?> updateProductCatalog(@RequestBody ProductCatalog catalog) {
        if (catalog == null) {
            return ResponseEntity.badRequest().build();
        }

        catalogService.updateProductCatalog(catalog);

        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteProductCatalog(@PathVariable("id") UUID id) {
        catalogService.deleteProductCatalog(id);
        return ResponseEntity.noContent().build();
    }
}
