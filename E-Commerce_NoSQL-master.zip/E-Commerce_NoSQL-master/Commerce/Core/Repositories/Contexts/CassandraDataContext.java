import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.api.core.CqlSessionBuilder;
import com.datastax.oss.driver.api.core.CqlSessionBuilderBase;
import com.datastax.oss.driver.api.core.CqlSessionBuilderFinalizer;
import com.datastax.oss.driver.api.core.CqlSessionBuilderInitializer;
import com.datastax.oss.driver.api.core.CqlSessionBuilderListener;
import com.datastax.oss.driver.api.core.CqlSessionBuilderSupport;
import com.datastax.oss.driver.api.core.CqlSessionBuilderTool;
import com.datastax.oss.driver.api.core.CqlSessionListener;
import com.datastax.oss.driver.api.core.config.DriverConfigLoader;
import com.datastax.oss.driver.api.core.metadata.Metadata;
import com.datastax.oss.driver.api.core.session.SessionBuilder;

import java.nio.file.Paths;

public class CassandraDataContext implements IConnection<CqlSession> {
    private CqlSession session;

    public CassandraDataContext(IConfiguration configuration) {
        CqlSessionBuilder builder = CqlSession.builder();

        builder = builder.withCloudSecureConnectionBundle(Paths.get("C:\\Users\\gonza\\Documents\\Programacion\\secure-connect-e-commerce-bd2.zip"))
                         .withCredentials(configuration.getValue("Databases:Cassandra:ClientID", String.class), configuration.getValue("Databases:Cassandra:ClientSecret", String.class));

        builder = builder.withConfigLoader(DriverConfigLoader.fromClasspath("application.conf"));

        session = builder.build();

        session = sessionBuilder.withKeyspace(configuration.getValue("Databases:Cassandra:KeySpace", String.class))
                                .build();

    }

    public CqlSession GetConnection() {
        return session;
    }
}
