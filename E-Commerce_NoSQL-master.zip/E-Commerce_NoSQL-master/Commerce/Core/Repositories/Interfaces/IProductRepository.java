using Commerce.Core.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Commerce.Core.Repositories.Interfaces
{
    public interface IProductRepository
    {
        Task<List<Product>> GetAll();

        Task<Product> GetById(Guid id);

        Task Insert(Product product);

        Task Update(Product product);

        Task Delete(Guid id);
    }
}
