import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.SerializationFeature;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class ExceptionHandler {
    private final ObjectMapper objectMapper;
    private final RequestDelegate nextMiddleware;

    public ExceptionHandler(RequestDelegate nextMiddleware) {
        this.nextMiddleware = nextMiddleware;
        this.objectMapper = new ObjectMapper();
        this.objectMapper.setPropertyNamingStrategy(PropertyNamingStrategy.SNAKE_CASE);
        this.objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    }

    public void invoke(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            nextMiddleware.invoke(request, response);
        } catch (AppException exception) {
            sendPayload(response, Envelope.error(exception.getMessage()), exception.getStatusCode());
        } catch (Exception exception) {
            sendPayload(response, Envelope.error(exception.getMessage()));
        }
    }

    private void sendPayload(HttpServletResponse response, Object payload, int statusCode) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.setStatus(statusCode);
        PrintWriter writer = response.getWriter();
        String payloadJson = objectMapper.writeValueAsString(payload);
        writer.write(payloadJson);
        writer.flush();
    }
}
