import java.time.LocalDateTime;

public final class Envelope {
    private String errorMessage;

    private Envelope(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public static <T> Envelope<T> ok(T result) {
        return new Envelope<>(result, null);
    }

    public static Envelope ok() {
        return new Envelope(null);
    }

    public static Envelope error(String errorMessage) {
        return new Envelope(errorMessage);
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}

public class Envelope<T> {
    private T result;
    private String errorMessage;
    private LocalDateTime timeGenerated;

    protected Envelope(T result, String errorMessage) {
        this.result = result;
        this.errorMessage = errorMessage;
        this.timeGenerated = LocalDateTime.now();
    }

    public T getResult() {
        return result;
    }

    public void setResult(T result) {
        this.result = result;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public LocalDateTime getTimeGenerated() {
        return timeGenerated;
    }

    public void setTimeGenerated(LocalDateTime timeGenerated) {
        this.timeGenerated = timeGenerated;
    }
}
