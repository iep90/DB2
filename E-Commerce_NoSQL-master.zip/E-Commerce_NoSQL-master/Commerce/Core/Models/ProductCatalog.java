import java.util.Date;
import java.util.UUID;

public class ProductCatalog {
    private UUID id;
    private UUID authorId;
    private UUID productId;
    private Date moment;
    private BigDecimal price;

    public ProductCatalog() {
        this.id = UUID.randomUUID();
    }

    public ProductCatalog(Row row) {
        this.id = row.getUUID("id");
        this.authorId = row.getUUID("authorId");
        this.productId = row.getUUID("productId");
        this.moment = row.getTimestamp("moment");
        this.price = row.getDecimal("price");
    }

    public UUID getId() {
        return id;
    }

    public UUID getAuthorId() {
        return authorId;
    }

    public void setAuthorId(UUID authorId) {
        this.authorId = authorId;
    }

    public UUID getProductId() {
        return productId;
    }

    public void setProductId(UUID productId) {
        this.productId = productId;
    }

    public Date getMoment() {
        return moment;
    }

    public void setMoment(Date moment) {
        this.moment = moment;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }
}
