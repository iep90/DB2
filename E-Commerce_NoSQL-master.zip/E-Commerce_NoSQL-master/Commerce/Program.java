import Commerce.Core.Helpers.Middleware.ExceptionHandler;
import Commerce.Core.Repositories.CatalogRepository;
import Commerce.Core.Repositories.OrderRepository;
import Commerce.Core.Repositories.PaymentRepository;
import Commerce.Core.Repositories.ProductRepository;
import Commerce.Core.Repositories.UserRepository;
import Commerce.Core.Repositories.Interfaces.ICatalogRepository;
import Commerce.Core.Repositories.Interfaces.IOrderRepository;
import Commerce.Core.Repositories.Interfaces.IPaymentRepository;
import Commerce.Core.Repositories.Interfaces.IProductRepository;
import Commerce.Core.Repositories.Interfaces.IUserRepository;
import Commerce.Core.Services.CatalogService;
import Commerce.Core.Services.OrderService;
import Commerce.Core.Services.PaymentService;
import Commerce.Core.Services.ProductService;
import Commerce.Core.Services.UserService;
import Commerce.Core.Services.Interfaces.ICatalogService;
import Commerce.Core.Services.Interfaces.IOrderService;
import Commerce.Core.Services.Interfaces.IPaymentService;
import Commerce.Core.Services.Interfaces.IProductService;
import Commerce.Core.Services.Interfaces.IUserService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public ICatalogRepository catalogRepository() {
        return new CatalogRepository();
    }

    @Bean
    public IOrderRepository orderRepository() {
        return new OrderRepository();
    }

    @Bean
    public IPaymentRepository paymentRepository() {
        return new PaymentRepository();
    }

    @Bean
    public IProductRepository productRepository() {
        return new ProductRepository();
    }

    @Bean
    public IUserRepository userRepository() {
        return new UserRepository();
    }

    @Bean
    public ICatalogService catalogService(ICatalogRepository catalogRepository) {
        return new CatalogService(catalogRepository);
    }

    @Bean
    public IOrderService orderService(IOrderRepository orderRepository) {
        return new OrderService(orderRepository);
    }

    @Bean
    public IPaymentService paymentService(IPaymentRepository paymentRepository) {
        return new PaymentService(paymentRepository);
    }

    @Bean
    public IProductService productService(IProductRepository productRepository) {
        return new ProductService(productRepository);
    }

    @Bean
    public IUserService userService(IUserRepository userRepository) {
        return new UserService(userRepository);
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
